package cetus.gui;

import cetus.exec.Driver;

public class SubDriver extends Driver{

    protected SubDriver() {
        super();//registerOptions();
    }

}
