package cetus.hir;

/* TODO: remove this */
public class ExceptionSpecification {
}
