/*  Loop with an unknown number of iterations
*/

  int main(){

  float a[10000], b[10000];
  int i, n;
  
  read_from_input(n);

  for (i=1; i<n; i++) {
    a[i]= 0;
  }
	
   return 0;
}
